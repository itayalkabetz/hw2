
public class StringUtils {

	public static String findSortedSequence(String str) {
		// TODO
		return null; //Replace this with the correct returned value

	}

	
	public static boolean isEditDistanceOne(String a, String b){
		// TODO
		return false; //Replace this with the correct returned value
	}
	
}
