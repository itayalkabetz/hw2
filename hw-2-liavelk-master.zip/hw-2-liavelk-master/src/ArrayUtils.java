
public class ArrayUtils {

	public static int[] shiftArrayCyclic(int[] array, int move, char direction) {
		// TODO
		return null; //Replace this with the correct returned value

	}


	public static int findShortestPath(int[][] m, int i, int j) {
		// TODO
		return 0; //Replace this with the correct returned value

	}

}
